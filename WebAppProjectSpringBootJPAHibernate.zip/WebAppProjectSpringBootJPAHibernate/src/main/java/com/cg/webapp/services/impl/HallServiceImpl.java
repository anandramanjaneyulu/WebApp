package com.cg.webapp.services.impl;

import com.cg.webapp.beans.Hall;
import com.cg.webapp.daoservices.HallRepository;
import com.cg.webapp.services.HallService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HallServiceImpl implements HallService {

    private HallRepository hallRepository;

    @Autowired
    public HallServiceImpl(HallRepository hallRepository) {
        this.hallRepository = hallRepository;
    }

    public List<Hall> getAllHall() {
        return hallRepository.findAll();
    }

    public Hall getHallByID(Long hallId) {
        return hallRepository.findOne(hallId);
    }


    public void deleteHallByID(Long id) {
        if (getHallByID(id) != null) {
            hallRepository.delete(id);
        }
    }

    public Hall addHall(Hall hall) {
        return hallRepository.saveAndFlush(hall);
    }

}
