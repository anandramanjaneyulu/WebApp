package com.cg.webapp.daoservices;

import com.cg.webapp.beans.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {

    User findByUsername(String userName);

    User findByEmail(String email);

    User findByPhone(String phone);
}

