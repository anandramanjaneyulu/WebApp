package com.cg.webapp.services;

import com.cg.webapp.beans.Hall;

import java.util.List;

public interface HallService {

    List<Hall> getAllHall();

    Hall getHallByID(Long id);

    void deleteHallByID(Long id);

    Hall addHall(Hall hall);

}
