package com.cg.webapp.daoservices;

import com.cg.webapp.beans.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

}
