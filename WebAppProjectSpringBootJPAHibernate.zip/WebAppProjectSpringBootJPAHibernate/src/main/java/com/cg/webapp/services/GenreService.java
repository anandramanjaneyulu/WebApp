package com.cg.webapp.services;

import com.cg.webapp.beans.Genre;

import java.util.List;

public interface GenreService {

    List<Genre> getAllGenre();

    Genre getGenreByID(Long id);

    void deleteGenreById(Long id);

    void addGenre(Genre genre);
}

