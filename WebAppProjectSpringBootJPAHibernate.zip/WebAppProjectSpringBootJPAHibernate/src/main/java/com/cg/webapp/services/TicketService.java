package com.cg.webapp.services;

import com.cg.webapp.beans.Ticket;
import org.springframework.data.domain.Page;

public interface TicketService {

    Page<Ticket> findAll(Integer pageNumber);

    Ticket findById(Long id);

    void update(Ticket ticket);
}
