package com.cg.webapp.daoservices;

import com.cg.webapp.beans.Row;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RowRepository extends JpaRepository<Row, Long> {
}
