package com.cg.webapp.daoservices;

import com.cg.webapp.beans.FilmSession;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FilmSessionRepository extends JpaRepository<FilmSession, Long> {
}
