package com.cg.webapp.services.impl;

import com.cg.webapp.beans.Row;
import com.cg.webapp.daoservices.RowRepository;
import com.cg.webapp.services.RowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RowServiceImpl implements RowService {

    private final RowRepository rowRepository;


    @Autowired
    public RowServiceImpl(RowRepository rowRepository) {
        this.rowRepository = rowRepository;
    }

    public Row addRow(Row row) {
        return rowRepository.saveAndFlush(row);
    }


    public List<Row> getAllRow() {
        return rowRepository.findAll();
    }
}
