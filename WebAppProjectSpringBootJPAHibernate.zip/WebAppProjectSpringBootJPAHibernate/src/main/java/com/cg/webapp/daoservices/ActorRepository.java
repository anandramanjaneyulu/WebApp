package com.cg.webapp.daoservices;

import com.cg.webapp.beans.Actor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActorRepository extends JpaRepository<Actor, Long> {
}
