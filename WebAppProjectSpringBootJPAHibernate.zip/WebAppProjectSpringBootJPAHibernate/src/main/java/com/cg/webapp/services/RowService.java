package com.cg.webapp.services;

import com.cg.webapp.beans.Row;

import java.util.List;

public interface RowService {

    Row addRow(Row row);

    List<Row> getAllRow();
}
