package com.cg.webapp.services.impl;

import com.cg.webapp.beans.Genre;
import com.cg.webapp.daoservices.GenreRepository;
import com.cg.webapp.services.GenreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenreServiceImpl implements GenreService {

    private final GenreRepository genreRepository;

    @Autowired
    public GenreServiceImpl(GenreRepository genreRepository) {
        this.genreRepository = genreRepository;
    }

    public List<Genre> getAllGenre() {
        return genreRepository.findAll();
    }

    public Genre getGenreByID(Long id) {
        return genreRepository.findOne(id);
    }

    public void deleteGenreById(Long id) {
        if (getGenreByID(id) != null)
            genreRepository.delete(id);
    }

    public void addGenre(Genre genre) {
        genreRepository.saveAndFlush(genre);
    }
}
