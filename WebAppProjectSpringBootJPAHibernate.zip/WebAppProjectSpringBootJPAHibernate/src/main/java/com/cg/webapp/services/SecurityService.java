package com.cg.webapp.services;

public interface SecurityService {

    void autoLogin(String username, String password);
}
