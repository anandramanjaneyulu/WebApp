package com.cg.webapp.daoservices;

import com.cg.webapp.beans.Hall;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HallRepository extends JpaRepository<Hall, Long> {
}
